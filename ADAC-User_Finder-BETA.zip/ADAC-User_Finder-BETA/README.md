# ADAC
Active Directory Automated Commands

Small program using tkinter as UI.
Consist of a better "search" of the Active directory (and faster)
